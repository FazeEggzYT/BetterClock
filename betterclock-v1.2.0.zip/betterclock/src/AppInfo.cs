namespace BetterClock
{
    // Version comes from version.txt at build time (build.bat writes obj\Version.g.cs).
    public static partial class AppInfo
    {
        public const string Product = "Better Clock";
    }
}
